# Sewa Academy Kenya — Official Website

Private Christian-aligned educational institution in Slota, Athi River (Machakos County), Kenya.

---

## Site Overview

This is a single-page responsive website built with React, Vite, Tailwind CSS, and vanilla JavaScript. All images are stored locally in the `public/img/` directory.

## Run Locally

Install [Node.js LTS](https://nodejs.org/) first, then run these commands from the project folder:

```bash
npm install
npm run dev
```

Open the local URL printed in the terminal (usually `http://localhost:5173`). To check the production version locally:

```bash
npm run build
npm run preview
```

## Responsive Screens & Replacing Images

The layout adapts to mobile phones, tablets, laptops, and desktop screens. The main navigation switches to a large, keyboard-accessible menu below desktop width; Home and section links scroll to their targets with space for the fixed header. The hero photo carousel can be changed using its controls and respects the reduced-motion setting. Content grids reflow on smaller screens. Test different widths with your browser's device toolbar and, before launch, check on an actual phone and tablet as well.

The page includes a responsive Gallery section, linked in the main navigation, and separate welcome messages for the Director, Headteacher, and teachers. The message wording is editable in the `leadershipMessages` list in `src/App.tsx`; please have the appropriate staff review and approve the text and names before publishing it as their official message.

To replace the sample photos later, put the new image files in `public/img/`. Keep the existing names to swap images without editing code:

- `hero-school.jpg` — home page hero and gallery
- `students.jpg`, `classroom.jpg`, `arts-sports.jpg`, and `holiday-camp.jpg` — additional hero slideshow photos
- `classroom.jpg` — About section and gallery
- `online-learning.jpg` — Online Learning program and gallery
- `holiday-camp.jpg` — International Holiday Camps and gallery
- `arts-sports.jpg` — Arts & Sports program and gallery
- `students.jpg` — Gallery
- `sewa-academy-logo.png` — logo beside the Sewa Academy name in the header and footer

If you use different filenames, update the matching `/img/filename` references in `src/App.tsx`, including the `heroPhotos` list for slideshow photos. Images in `public/` are served from the site root, so the code uses `/img/filename`. Re-run `npm run build` after replacing assets; the files will be copied to `dist/img/`.

---

## Google Indexing & SEO Setup

### 1. Google Indexing (robots.txt + meta tags)
- `robots.txt` allows all crawlers: `User-agent: *` / `Allow: /`
- Meta tags include: `description`, `keywords`, `author`, `robots`, `canonical`
- Open Graph (`og:`) and Twitter Card meta tags included in `index.html`
- Structured data (JSON-LD) script added for School organization

### 2. Sitemap
The sitemap is in `public/sitemap.xml` and is copied to the production `dist/` folder. Because this is a single-page site, it lists the canonical homepage only; section links such as `#about` are not separate sitemap pages. Before launch, update its domain to the final website domain. Once deployed, submit `https://YOUR-DOMAIN/sitemap.xml` in Google Search Console:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://sewaacademykenya.weebly.com/</loc></url>
</urlset>
```

### 3. Search Console
- Add and verify the final website domain in [Google Search Console](https://search.google.com/search-console/).
- Submit the deployed sitemap at `https://YOUR-DOMAIN/sitemap.xml`.
- Use URL Inspection to request indexing for the live homepage.
- Replace the example `sewaacademykenya.weebly.com` domain in `index.html`, `public/robots.txt`, and `public/sitemap.xml` if the final domain is different.
- Google controls crawling and indexing; submitting a sitemap or requesting indexing does not guarantee inclusion or a particular ranking.

---

## Google Analytics Setup

A `gtag.js` snippet is embedded in `index.html` (commented with placeholder `G-XXXXXXXXXX`).

To activate:
1. Create a new Google Analytics 4 property at https://analytics.google.com/
2. Copy the Measurement ID (e.g., `G-ABC123DEF`)
3. Replace `G-XXXXXXXXXX` in `index.html` with your Measurement ID
4. Verify via Real-Time reports in GA4

---

## Best SEO Practices Applied

- Semantic HTML (`header`, `main`, `section`, `article`, `footer`, `nav`)
- Proper heading hierarchy (`h1` → `h2` → `h3`)
- Descriptive `alt` text on all images
- Internal anchor links (`#programs`, `#contact`, etc.)
- Mobile-first responsive design
- Fast load times (local images, optimized assets)
- HTTPS ready (serve via secure host)
- Clean, crawlable URLs (single-page with hash anchors)
- Sitemap includes the canonical homepage URL
- Keyword-rich content: "Sewa Academy Kenya", "Athi River school", "Christian school Kenya", "Junior Secondary Grade 7-9"

---

## Image Assets

All images are placed in `public/img/`:

- `sewa-academy-logo.png` — School crest displayed beside the Sewa Academy name in the header and footer
- `hero-school.jpg` — School building and grounds
- `classroom.jpg` — Modern classroom interior
- `students.jpg` — Students outdoors
- `arts-sports.jpg` — Arts & creative activities
- `online-learning.jpg` — Online learning setup
- `holiday-camp.jpg` — Holiday language camp

---

## Project Structure

```
public/
  img/          # All image assets
src/
  App.tsx       # Main single-page app
  index.css     # Tailwind + custom styles
index.html      # SEO meta tags + Google tags
vite.config.ts  # Build configuration
```

---

## Hosting / Deployment

Create a production build:
```bash
npm run build
```

Deploy the generated `dist/` folder, not the source folder. It contains the built site and the `img/`, `robots.txt`, and `sitemap.xml` files.

Before the first production build, update the canonical URL, Open Graph URL, sitemap URL, and `robots.txt` sitemap URL to your final domain. The current `sewaacademykenya.weebly.com` value should only stay if that is the actual domain you deploy.

### Netlify

1. Push this project to a GitHub, GitLab, or Bitbucket repository and import it in Netlify.
2. Set the build command to `npm run build` and the publish directory to `dist`.
3. Deploy, connect your custom domain if you have one, and enable HTTPS.

### Vercel

1. Import the project repository in Vercel.
2. Select Vite if prompted; use `npm run build` as the build command and `dist` as the output directory.
3. Deploy, connect your custom domain if you have one, and enable HTTPS.

### cPanel or Other Static Hosting

1. Run `npm run build` on your computer.
2. Upload the **contents** of `dist/` into the host's web root (often `public_html`). Keep the `img/` folder and its contents in place.
3. Enable HTTPS, then visit the live homepage and check that images, the map, and WhatsApp link work.

The current contact form is a front-end demo and displays a confirmation message; connect it to a form service or backend before using it to receive real inquiries.

For GitHub Pages project sites, configure Vite's `base` path for the repository name before building. Custom domains and root-domain hosting generally use `/`.

After deployment, update the SEO domain references, then submit the live sitemap in Google Search Console.
