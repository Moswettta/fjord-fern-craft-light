import { useState, useEffect } from 'react';
import { Menu, X, MapPin, Phone, Mail, ChevronLeft, ChevronRight, GraduationCap, Heart, Sparkles, BookOpen, Globe2, Pause, Play } from 'lucide-react';

const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Programs', href: '#programs' },
  { label: 'Approach', href: '#approach' },
  { label: 'Messages', href: '#messages' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'Contact', href: '#contact' },
];

const programs = [
  {
    title: 'Play Group',
    age: 'Ages 2 – 4',
    desc: 'A warm, nurturing start for early learners with guided play, storytelling, basic numeracy, and social skills in a Christian environment.',
    icon: Sparkles,
  },
  {
    title: 'Kindergarten',
    age: 'Ages 4 – 6',
    desc: 'Foundational learning blending play and structured activity. Focus on literacy, early mathematics, creativity, and character building.',
    icon: Heart,
  },
  {
    title: 'Primary School',
    age: 'Grade 1 – 6',
    desc: 'Strong CBC-aligned academics with emphasis on critical thinking, reading, science, ICT basics, and moral development.',
    icon: BookOpen,
  },
  {
    title: 'Junior Secondary',
    age: 'Grade 7 – 9',
    desc: 'Preparation for senior secondary with deeper subject mastery, leadership development, and guided career exploration.',
    icon: GraduationCap,
  },
];

const extras = [
  {
    title: 'Online Learning',
    range: 'Grades 1 – 7',
    desc: 'Flexible online lessons for families needing remote or blended education. Includes live instruction, digital resources, and progress tracking.',
    more: 'Learners can review lessons and practice at a pace that suits them. Contact the academy for current schedules, access requirements, and availability for Grades 1–7.',
    image: '/img/online-learning.jpg',
  },
  {
    title: 'International Holiday Camps',
    range: 'All Ages',
    desc: 'Specialized language camps and holiday programs promoting creativity, teamwork, and cross-cultural awareness during school breaks.',
    more: 'Camp dates, language options, and activities can vary during the year. Get in touch with the academy for upcoming sessions and registration details.',
    image: '/img/holiday-camp.jpg',
  },
  {
    title: 'Arts & Sports',
    range: 'All Levels',
    desc: 'Arts, music, drama, and sports programs integrated into the curriculum to nurture talent, teamwork, and healthy confidence.',
    more: 'Creative and physical activities give learners opportunities to explore interests, express ideas, and grow through participation. Ask the academy about current activities and schedules.',
    image: '/img/arts-sports.jpg',
  },
];

const gallery = [
  { src: '/img/hero-school.jpg', caption: 'Sewa Academy Campus, Slota' },
  { src: '/img/classroom.jpg', caption: 'Bright Modern Classrooms' },
  { src: '/img/students.jpg', caption: 'Students at Play' },
  { src: '/img/arts-sports.jpg', caption: 'Arts & Creative Learning' },
  { src: '/img/online-learning.jpg', caption: 'Online Learning Program' },
  { src: '/img/holiday-camp.jpg', caption: 'Holiday Language Camp' },
];

const heroPhotos = [
  { src: '/img/hero-school.jpg', alt: 'Sewa Academy campus in Athi River' },
  { src: '/img/students.jpg', alt: 'Sewa Academy learners enjoying time together' },
  { src: '/img/classroom.jpg', alt: 'A bright classroom ready for learning' },
  { src: '/img/arts-sports.jpg', alt: 'Learners exploring creative activities' },
  { src: '/img/holiday-camp.jpg', alt: 'Learners taking part in a holiday camp' },
];

const leadershipMessages = [
  {
    role: 'Director',
    title: "A message from the Director",
    message: 'At Sewa Academy, we believe education should help every learner discover their strengths and prepare to contribute with confidence and compassion. We work alongside families to create an encouraging, values-led community where academic effort and personal growth go hand in hand.',
  },
  {
    role: 'Headteacher',
    title: "A message from the Headteacher",
    message: 'Every day is an opportunity to learn, ask questions, and make progress. Our school community aims to give learners a strong foundation, clear guidance, and a caring place to grow from Play Group through Junior Secondary.',
  },
  {
    role: 'Teacher',
    title: "A message from our teachers",
    message: 'In the classroom, we want each learner to feel seen, supported, and confident to try. We encourage curiosity, creativity, kindness, and perseverance so students can learn from one another and take pride in every step forward.',
  },
];

export default function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [expandedExtras, setExpandedExtras] = useState<Record<string, boolean>>({});
  const [heroSlide, setHeroSlide] = useState(0);
  const [heroPaused, setHeroPaused] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMobileOpen(false);
    };
    const closeOnDesktop = () => {
      if (window.matchMedia('(min-width: 1024px)').matches) setMobileOpen(false);
    };

    window.addEventListener('keydown', closeOnEscape);
    window.addEventListener('resize', closeOnDesktop);
    return () => {
      window.removeEventListener('keydown', closeOnEscape);
      window.removeEventListener('resize', closeOnDesktop);
    };
  }, []);

  useEffect(() => {
    if (heroPaused || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const interval = window.setInterval(() => {
      setHeroSlide((current) => (current + 1) % heroPhotos.length);
    }, 6500);

    return () => window.clearInterval(interval);
  }, [heroPaused]);

  return (
    <div className="min-h-screen bg-parchment font-body text-ink">
      {/* Navigation */}
      <nav
        aria-label="Main navigation"
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
          scrolled || mobileOpen ? 'nav-glass shadow-sm py-3' : 'bg-transparent py-5'
        }`}
      >
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 sm:px-6">
          <a href="#home" onClick={() => setMobileOpen(false)} className={`flex min-w-0 items-center gap-3 ${scrolled || mobileOpen ? 'text-forest' : 'text-white'}`}>
            <img
              src="/img/sewa-academy-logo.png"
              alt="Sewa Academy logo"
              className="h-12 w-12 shrink-0 object-contain drop-shadow-md"
            />
            <div className="leading-tight">
              <div className="font-display text-xl font-semibold tracking-tight">Sewa Academy</div>
              <div className={`text-[10px] tracking-[0.22em] uppercase font-medium ${scrolled ? 'text-ink-muted' : 'text-white/80'}`}>Kenya</div>
            </div>
          </a>

          {/* Desktop links */}
          <div className="hidden lg:flex items-center gap-4 xl:gap-7">
            {navLinks.map((link) => (
              <a key={link.href} href={link.href} onClick={() => setMobileOpen(false)} className={`whitespace-nowrap text-sm font-medium tracking-wide transition-colors hover:text-gold ${scrolled ? 'text-ink-soft hover:text-forest' : 'text-white/90 hover:text-white'}`}>
                {link.label}
              </a>
            ))}
            <a href="#contact" className="text-sm font-semibold bg-forest text-white px-5 py-2.5 rounded-full hover:bg-forest-deep hover:shadow-lg hover:shadow-forest/20 transition-all">
              Enroll
            </a>
          </div>

          {/* Mobile toggle */}
          <button
            type="button"
            onClick={() => setMobileOpen((open) => !open)}
            className={`inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full transition-colors hover:bg-forest/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold lg:hidden ${scrolled || mobileOpen ? 'text-forest' : 'text-white'}`}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
            aria-controls="mobile-navigation"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div
            id="mobile-navigation"
            role="region"
            aria-label="Mobile navigation links"
            className="absolute inset-x-0 top-full max-h-[calc(100svh-4.5rem)] overflow-y-auto border-t border-stone bg-white shadow-2xl animate-[slideDown_0.25s_ease] lg:hidden"
          >
            <div className="mx-auto flex max-w-6xl flex-col gap-1 px-4 py-4 sm:px-6">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="flex min-h-12 items-center rounded-xl px-4 py-3 text-base font-semibold text-ink-soft transition-colors hover:bg-cream hover:text-forest active:bg-stone/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold"
                >
                  {link.label}
                </a>
              ))}
              <a
                href="#contact"
                onClick={() => setMobileOpen(false)}
                className="mt-2 flex min-h-12 items-center justify-center rounded-full bg-forest px-5 py-3 font-semibold text-white shadow-md transition-colors hover:bg-forest-deep active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold focus-visible:ring-offset-2"
              >
                Enroll
              </a>
            </div>
          </div>
        )}
      </nav>

      {/* Hero */}
      <header id="home" className="relative flex min-h-[620px] h-[92svh] items-center overflow-hidden scroll-mt-0">
        <div className="absolute inset-0" role="region" aria-label="Sewa Academy photo slideshow" aria-roledescription="carousel">
          {heroPhotos.map((photo, index) => (
            <img
              key={photo.src}
              src={photo.src}
              alt={index === heroSlide ? photo.alt : ''}
              aria-hidden={index !== heroSlide}
              loading={index === 0 ? 'eager' : 'lazy'}
              decoding="async"
              className={`absolute inset-0 h-full w-full object-cover object-center transition-opacity duration-1000 ${index === heroSlide ? 'opacity-100' : 'opacity-0'}`}
            />
          ))}
          <div className="absolute inset-0 bg-forest-deep/65" />
        </div>

        <div className="relative z-10 mx-auto w-full max-w-6xl px-4 pt-20 sm:px-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/10 text-white/90 text-xs md:text-sm px-4 py-1.5 rounded-full mb-8 tracking-wide font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-gold animate-pulse" />
              Private Christian School — Slota, Athi River
            </div>
            <h1 className="mb-6 font-display text-4xl font-semibold leading-[0.96] tracking-tight text-white sm:text-6xl md:text-7xl lg:text-8xl">
              Nurturing Minds,<br />
              <span className="italic text-gold-light">Shaping Character</span>
            </h1>
            <p className="text-white/85 text-base md:text-xl leading-relaxed max-w-2xl mb-10 font-light">
              Sewa Academy Kenya offers holistic, Christian-aligned education for Play Group through Junior Secondary — building excellence, creativity, and character in every child.
            </p>
            <div className="flex flex-wrap gap-3 sm:gap-4">
              <a href="#programs" className="inline-flex min-h-12 items-center justify-center rounded-full bg-gold px-6 py-3 text-sm font-bold tracking-wide text-forest-deep transition-all hover:bg-gold-light hover:shadow-xl hover:shadow-gold/25 sm:px-8 sm:py-4">
                Explore Programs
              </a>
              <a href="#contact" className="inline-flex min-h-12 items-center justify-center rounded-full border border-white/20 bg-white/8 px-6 py-3 text-sm font-medium tracking-wide text-white backdrop-blur-sm transition-all hover:border-white/30 hover:bg-white/15 sm:px-8 sm:py-4">
                Contact Us
              </a>
            </div>

            <div className="mt-7 flex items-center gap-2" aria-label="Slideshow controls">
              <button
                type="button"
                onClick={() => setHeroSlide((current) => (current - 1 + heroPhotos.length) % heroPhotos.length)}
                className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/30 bg-forest-deep/40 text-white transition-colors hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold"
                aria-label="Previous hero photo"
              >
                <ChevronLeft size={18} />
              </button>
              {heroPhotos.map((photo, index) => (
                <button
                  key={photo.src}
                  type="button"
                  onClick={() => setHeroSlide(index)}
                  className={`h-3 rounded-full transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold focus-visible:ring-offset-2 focus-visible:ring-offset-forest-deep ${index === heroSlide ? 'w-7 bg-gold' : 'w-3 bg-white/60 hover:bg-white'}`}
                  aria-label={`Show hero photo ${index + 1}`}
                  aria-current={index === heroSlide ? 'true' : undefined}
                />
              ))}
              <button
                type="button"
                onClick={() => setHeroPaused((paused) => !paused)}
                className="ml-1 inline-flex h-10 w-10 items-center justify-center rounded-full border border-white/30 bg-forest-deep/40 text-white transition-colors hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold"
                aria-label={heroPaused ? 'Play hero slideshow' : 'Pause hero slideshow'}
              >
                {heroPaused ? <Play size={16} /> : <Pause size={16} />}
              </button>
              <span className="sr-only" aria-live="polite">Photo {heroSlide + 1} of {heroPhotos.length}</span>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/50 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-1.5">
            <div className="w-1 h-2 bg-white/60 rounded-full" />
          </div>
        </div>
      </header>

      {/* Marquee Banner */}
        <div className="bg-forest-deep text-white overflow-hidden border-y border-white/5 relative">
          <div className="marquee-track flex whitespace-nowrap gap-12 px-6 py-3 items-center">
            {[
              'Private Christian School — Slota, Athi River • Machakos County • Kenya',
              'Play Group • Kindergarten • Primary School Grade 1-6 • Junior Secondary Grade 7-9',
              'Online Learning Grades 1-7 • Holiday Language Camps • Arts & Sports Programs',
              'Contact: +254 795 893 804 • WhatsApp Available • Facebook: Sewa Academy AthiRiver',
              'Holistic Education • Character Development • Academic Excellence • Creative Growth',
              'Private Christian School — Slota, Athi River • Machakos County • Kenya',
              'Play Group • Kindergarten • Primary School Grade 1-6 • Junior Secondary Grade 7-9',
              'Online Learning Grades 1-7 • Holiday Language Camps • Arts & Sports Programs',
              'Contact: +254 795 893 804 • WhatsApp Available • Facebook: Sewa Academy AthiRiver',
              'Holistic Education • Character Development • Academic Excellence • Creative Growth',
            ].map((text, i) => (
              <span key={i} className="inline-flex items-center gap-4 text-sm md:text-base font-medium tracking-wide text-white/90 shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-gold" />
                {text}
              </span>
            ))}
          </div>
        </div>

      {/* About */}
      <section id="about" className="relative py-24 lg:py-32 overflow-hidden">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 items-start">
            <div className="lg:col-span-5 relative">
              <div className="img-zoom rounded-3xl shadow-2xl shadow-forest/10 overflow-hidden">
                <img src="/img/classroom.jpg" alt="Classroom at Sewa Academy" className="w-full h-[420px] lg:h-[580px] object-cover" />
              </div>
              <div className="absolute -bottom-6 -right-4 lg:-right-6 bg-forest text-white rounded-2xl p-6 shadow-2xl shadow-forest/20 max-w-[240px]">
                <div className="font-display text-5xl font-semibold text-gold">4</div>
                <div className="text-sm text-white/80 mt-2 leading-snug">Levels of learning from Play Group to Junior Secondary</div>
              </div>
            </div>

            <div className="lg:col-span-7 lg:pt-8">
              <div className="decorative-line mb-5" />
              <h2 className="font-display text-4xl md:text-5xl font-semibold text-forest mb-4 gold-underline">
                About Sewa Academy
              </h2>
              <h3 className="text-xl md:text-2xl text-ink-muted font-light italic font-display mb-8">
                A Christian-aligned school in Slota, Athi River, building excellence in every child.
              </h3>

              <div className="prose prose-lg text-ink-soft leading-relaxed space-y-5 mb-10">
                <p>
                  Sewa Academy Kenya is a private, Christian-aligned educational institution located in Slota, Athi River, Machakos County. We serve learners from Play Group through Junior Secondary School, offering a holistic approach that blends academic excellence with character development, creativity, and spiritual growth.
                </p>
                <p>
                  Our vision is to produce well-rounded individuals who are confident, compassionate, and equipped for life. With dedicated teachers, modern classrooms, and a warm community, every child is encouraged to discover their purpose and develop their unique talents.
                </p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: 'Location', value: 'Slota, Athi River', icon: MapPin },
                  { label: 'Levels', value: 'Play Group — Grade 9', icon: GraduationCap },
                  { label: 'Learning', value: 'In-Person & Online', icon: Globe2 },
                  { label: 'Faith', value: 'Christian-aligned', icon: Heart },
                ].map((item) => (
                  <div key={item.label} className="bg-white rounded-2xl p-5 shadow-sm border border-stone/40 hover:shadow-md hover:border-gold/30 transition-all">
                    <item.icon size={22} className="text-gold mb-3" />
                    <div className="text-[11px] uppercase tracking-wider text-ink-muted font-semibold">{item.label}</div>
                    <div className="text-sm font-medium text-ink-soft mt-1">{item.value}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Programs */}
      <section id="programs" className="bg-forest-deep text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-gold/5 rounded-full -translate-y-1/3 translate-x-1/4 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-gold/5 rounded-full translate-y-1/3 -translate-x-1/4 blur-3xl" />

        <div className="relative max-w-6xl mx-auto px-6 py-24 lg:py-32">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 text-gold text-xs uppercase tracking-[0.2em] px-4 py-1.5 rounded-full mb-5 font-semibold">
              Our Levels
            </div>
            <h2 className="font-display text-4xl md:text-6xl font-semibold mb-5">Programs</h2>
            <p className="text-white/70 text-lg max-w-2xl mx-auto font-light">
              From early play to junior secondary, each level is designed with care, structure, and purpose.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {programs.map((prog) => (
              <a href="#contact" key={prog.title} className="group bg-white/5 border border-white/8 rounded-3xl p-8 card-hover backdrop-blur-sm hover:bg-white/8 transition-colors">
                <div className="w-14 h-14 rounded-2xl bg-gold text-forest-deep flex items-center justify-center mb-6 shadow-lg shadow-gold/20 group-hover:scale-105 transition-transform">
                  <prog.icon size={26} strokeWidth={2} />
                </div>
                <h3 className="font-display text-2xl font-semibold mb-1">{prog.title}</h3>
                <div className="text-gold text-sm font-medium mb-4">{prog.age}</div>
                <p className="text-white/70 text-sm leading-relaxed">{prog.desc}</p>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Approach / Features */}
      <section id="approach" className="py-24 lg:py-32 bg-cream">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="decorative-line mx-auto mb-5" />
            <h2 className="font-display text-4xl md:text-5xl font-semibold text-forest mb-4">Our Approach</h2>
            <p className="text-ink-muted text-lg max-w-2xl mx-auto">Holistic education that nurtures the mind, character, creativity, and spirit.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: 'Academic Excellence',
                desc: 'Rigorous CBC-aligned curriculum with qualified teachers, modern resources, and personalized attention to help every student reach their potential.',
                icon: BookOpen,
                bg: 'bg-forest',
                text: 'text-white',
              },
              {
                title: 'Character Development',
                desc: 'Christian values of integrity, respect, and service are woven into daily life, helping students grow into ethical, compassionate leaders.',
                icon: Heart,
                bg: 'bg-forest-deep',
                text: 'text-white',
              },
              {
                title: 'Creativity & Sports',
                desc: 'Arts, music, drama, sports, and clubs give students room to explore talents, build confidence, and work as a team.',
                icon: Sparkles,
                bg: 'bg-gold',
                text: 'text-forest-deep',
              },
            ].map((feat) => (
              <div key={feat.title} className="bg-white rounded-3xl p-8 shadow-sm border border-stone/40 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                <div className={`w-14 h-14 rounded-2xl ${feat.bg} ${feat.text} flex items-center justify-center mb-6 shadow-md`}>
                  <feat.icon size={24} strokeWidth={2} />
                </div>
                <h3 className="font-display text-2xl font-semibold text-ink mb-3">{feat.title}</h3>
                <p className="text-ink-muted leading-relaxed text-sm">{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Extras / Additional Services */}
      <section className="py-24 lg:py-32 bg-parchment">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="decorative-line mx-auto mb-5" />
            <h2 className="font-display text-4xl md:text-5xl font-semibold text-forest mb-4">Programs & Extras</h2>
            <p className="text-ink-muted text-lg max-w-2xl mx-auto">Beyond the classroom — online learning, holiday camps, and co-curricular enrichment.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {extras.map((extra, index) => {
              const isExpanded = expandedExtras[extra.title] ?? false;
              const detailsId = `extra-details-${index}`;

              return (
                <article key={extra.title} className="bg-white rounded-3xl overflow-hidden shadow-sm border border-stone/40 card-hover">
                  <div className="img-zoom h-56 relative">
                    <img src={extra.image} alt={extra.title} loading="lazy" className="w-full h-full object-cover" />
                    <div className="absolute top-4 right-4 bg-white/90 backdrop-blur text-forest-deep text-xs font-bold px-3 py-1 rounded-full shadow-sm">
                      {extra.range}
                    </div>
                  </div>
                  <div className="p-6 sm:p-7">
                    <h3 className="font-display text-xl font-semibold text-ink mb-2">{extra.title}</h3>
                    <p className="text-ink-muted text-sm leading-relaxed">{extra.desc}</p>
                    <div id={detailsId} hidden={!isExpanded} className="mt-3 border-t border-stone/60 pt-3">
                      <p className="text-ink-muted text-sm leading-relaxed">{extra.more}</p>
                    </div>
                    <button
                      type="button"
                      aria-expanded={isExpanded}
                      aria-controls={detailsId}
                      onClick={() => setExpandedExtras((current) => ({ ...current, [extra.title]: !isExpanded }))}
                      className="mt-4 inline-flex min-h-11 items-center gap-2 rounded-lg text-sm font-bold text-forest transition-colors hover:text-gold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold focus-visible:ring-offset-2"
                    >
                      {isExpanded ? 'Read less' : 'Read more'}
                      <ChevronRight size={16} className={`transition-transform ${isExpanded ? 'rotate-90' : ''}`} aria-hidden="true" />
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      {/* Messages from the school team */}
      <section id="messages" className="bg-white py-20 sm:py-24 lg:py-28">
        <div className="mx-auto max-w-6xl px-6">
          <div className="mb-12 max-w-3xl">
            <div className="decorative-line mb-5" />
            <h2 className="font-display text-4xl font-semibold text-forest sm:text-5xl">Messages from Our Team</h2>
            <p className="mt-4 max-w-2xl text-base leading-relaxed text-ink-muted sm:text-lg">
              A warm welcome from the people who guide, teach, and support our learners every day.
            </p>
          </div>

          <div className="grid gap-x-10 gap-y-12 md:grid-cols-3">
            {leadershipMessages.map((item, index) => (
              <article key={item.role} className="border-t-2 border-gold pt-5">
                <div className="mb-4 text-xs font-bold uppercase tracking-[0.18em] text-ink-muted">
                  Message 0{index + 1}
                </div>
                <h3 className="font-display text-2xl font-semibold text-forest">{item.title}</h3>
                <p className="mt-4 text-sm leading-7 text-ink-soft sm:text-base">{item.message}</p>
                <p className="mt-5 text-sm font-semibold text-forest">{item.role}, Sewa Academy</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section id="gallery" className="py-20 sm:py-24 lg:py-32 bg-forest-deep text-white relative overflow-hidden">
        <div className="relative max-w-6xl mx-auto px-6">
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 text-gold text-xs uppercase tracking-[0.2em] px-4 py-1.5 rounded-full mb-5 font-semibold">
              Moments
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-semibold mb-4">Gallery</h2>
            <p className="text-white/60 text-lg max-w-xl mx-auto">Life at Sewa Academy — classrooms, play, creativity, and community.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-5">
            {gallery.map((item, i) => (
              <figure key={item.src} className={`group rounded-3xl overflow-hidden shadow-xl shadow-black/20 ${i === 0 ? 'md:col-span-2 md:row-span-2' : ''}`}>
                <div className="relative h-64 md:h-full min-h-[260px] overflow-hidden">
                  <img src={item.src} alt={item.caption} loading="lazy" decoding="async" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                  <figcaption className="absolute inset-x-0 bottom-0 bg-forest-deep/85 px-5 py-3">
                    <p className="text-white text-sm font-medium">{item.caption}</p>
                  </figcaption>
                </div>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-24 lg:py-32 bg-cream">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
            <div>
              <div className="decorative-line mb-5" />
              <h2 className="font-display text-4xl md:text-5xl font-semibold text-forest mb-4">Contact</h2>
              <h3 className="text-xl text-ink-muted font-light italic font-display mb-8">We would love to hear from you. Reach out for enrollment or any questions.</h3>

              <div className="space-y-6 mb-10">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-forest text-gold flex items-center justify-center shrink-0 shadow-md shadow-forest/10">
                    <MapPin size={20} />
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-wider text-ink-muted font-semibold">Location</div>
                    <div className="text-ink-soft font-medium">Slota, Athi River, Machakos County, Kenya</div>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-forest text-gold flex items-center justify-center shrink-0 shadow-md shadow-forest/10">
                    <Phone size={20} />
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-wider text-ink-muted font-semibold">Phone / WhatsApp</div>
                    <a href="tel:+254795893804" className="text-ink-soft font-medium hover:text-forest transition-colors">+254 795 893 804</a>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-forest text-gold flex items-center justify-center shrink-0 shadow-md shadow-forest/10">
                    <Mail size={20} />
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-wider text-ink-muted font-semibold">Official Website</div>
                    <a href="#" className="text-ink-soft font-medium hover:text-forest transition-colors">Sewa Academy Weebly</a>
                  </div>
                </div>
              </div>

              <a href="#" className="inline-flex items-center gap-2 text-sm font-bold text-forest hover:text-forest-deep transition-colors">
                Visit Facebook Page <ChevronRight size={16} />
              </a>
            </div>

            {/* Google Maps Embed */}
            <div className="bg-white rounded-3xl overflow-hidden shadow-xl shadow-forest/5 border border-stone/40 mb-8">
              <iframe
                title="Sewa Academy Kenya - Slota, Athi River"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.7123456789!2d36.99!3d-1.48!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zLTAuODUsIDM2Ljk5!5e0!3m2!1sen!2ske!4v1234567890123!5m2!1sen!2ske"
                width="100%"
                height="320"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
              <div className="p-6 flex items-center justify-between">
                <div>
                  <h4 className="font-display text-lg font-semibold text-ink">Sewa Academy Kenya</h4>
                  <p className="text-sm text-ink-muted">Slota, Athi River, Machakos County</p>
                </div>
                <a href="https://www.google.com/maps/dir//Slota,+Athi+River,+Machakos+County,+Kenya"
                  target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-forest text-white text-xs font-bold px-4 py-2.5 rounded-full hover:bg-forest-deep transition-colors shadow-md shadow-forest/10"
                >
                  <MapPin size={14} />
                  Get Directions
                </a>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-8 lg:p-10 shadow-xl shadow-forest/5 border border-stone/40">
              <h3 className="font-display text-2xl font-semibold text-ink mb-2">Request Information</h3>
              <p className="text-ink-muted text-sm mb-7">Fill in your details and our team will respond within 24 hours.</p>
              <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); alert('Thank you! We will reach out shortly.'); }}>
                <div className="grid md:grid-cols-2 gap-5">
                  <input type="text" placeholder="First Name" className="w-full px-5 py-3.5 rounded-xl bg-cream border border-stone/60 text-ink text-sm placeholder:text-ink-muted/60 focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold transition-all" required />
                  <input type="text" placeholder="Last Name" className="w-full px-5 py-3.5 rounded-xl bg-cream border border-stone/60 text-ink text-sm placeholder:text-ink-muted/60 focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold transition-all" required />
                </div>
                <input type="email" placeholder="Email Address" className="w-full px-5 py-3.5 rounded-xl bg-cream border border-stone/60 text-ink text-sm placeholder:text-ink-muted/60 focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold transition-all" required />
                <input type="tel" placeholder="Phone / WhatsApp" className="w-full px-5 py-3.5 rounded-xl bg-cream border border-stone/60 text-ink text-sm placeholder:text-ink-muted/60 focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold transition-all" />
                <select className="w-full px-5 py-3.5 rounded-xl bg-cream border border-stone/60 text-ink text-sm focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold transition-all" defaultValue="">
                  <option value="">Program of Interest</option>
                  <option>Play Group</option>
                  <option>Kindergarten</option>
                  <option>Primary School (Grade 1-6)</option>
                  <option>Junior Secondary (Grade 7-9)</option>
                  <option>Online Learning</option>
                  <option>Holiday Camps</option>
                </select>
                <textarea rows={4} placeholder="Message or questions..." className="w-full px-5 py-3.5 rounded-xl bg-cream border border-stone/60 text-ink text-sm placeholder:text-ink-muted/60 focus:outline-none focus:ring-2 focus:ring-gold/40 focus:border-gold transition-all resize-none" />
                <button type="submit" className="w-full bg-forest text-white py-4 rounded-xl font-bold text-sm hover:bg-forest-deep hover:shadow-lg hover:shadow-forest/20 transition-all tracking-wide">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-forest-deep text-white border-t border-white/5">
        <div className="max-w-6xl mx-auto px-6 py-16 lg:py-20">
          <div className="grid md:grid-cols-4 gap-10 lg:gap-14">
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-5">
                <img
                  src="/img/sewa-academy-logo.png"
                  alt="Sewa Academy logo"
                  className="h-12 w-12 shrink-0 object-contain"
                />
                <div className="leading-tight">
                  <div className="font-display text-xl font-semibold tracking-tight">Sewa Academy</div>
                  <div className="text-[10px] tracking-[0.22em] uppercase text-white/40 font-medium">Kenya</div>
                </div>
              </div>
              <p className="text-white/55 text-sm leading-relaxed max-w-md">
                A private Christian-aligned school in Slota, Athi River, offering holistic education from Play Group through Junior Secondary — building minds and shaping character.
              </p>
            </div>
            <div>
              <h4 className="text-xs uppercase tracking-[0.2em] text-gold font-bold mb-5">Quick Links</h4>
              <ul className="space-y-3 text-sm text-white/55">
                <li><a href="#about" className="hover:text-white transition-colors">About</a></li>
                <li><a href="#programs" className="hover:text-white transition-colors">Programs</a></li>
                <li><a href="#approach" className="hover:text-white transition-colors">Our Approach</a></li>
                <li><a href="#gallery" className="hover:text-white transition-colors">Gallery</a></li>
                <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-xs uppercase tracking-[0.2em] text-gold font-bold mb-5">Contact</h4>
              <ul className="space-y-3 text-sm text-white/55">
                <li>Slota, Athi River</li>
                <li>Machakos County</li>
                <li><a href="tel:+254795893804" className="hover:text-white transition-colors">+254 795 893 804</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Facebook Page</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Weebly Website</a></li>
              </ul>
            </div>
          </div>

          <div className="mt-14 pt-8 border-t border-white/6 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-white/30">
            <div>&copy; {new Date().getFullYear()} Sewa Academy Kenya. All rights reserved.</div>
            <div>Built for education. Designed for growth.</div>
          </div>
        </div>
      </footer>

      <a
        href="https://wa.me/254795893804?text=Hello%20Sewa%20Academy%2C%20I%27d%20like%20to%20ask%20about%20enrollment."
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with Sewa Academy on WhatsApp"
        title="Chat with us on WhatsApp"
        className="fixed bottom-6 right-6 z-[60] inline-flex items-center gap-3 rounded-full bg-[#25D366] px-4 py-4 text-white shadow-xl shadow-green-950/25 transition duration-300 hover:scale-105 hover:bg-[#1ebe5d] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-green-300 sm:px-5"
      >
        <svg viewBox="0 0 24 24" className="h-7 w-7 shrink-0 fill-current" aria-hidden="true">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.198-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.372-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.626.712.227 1.36.195 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.999-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.002-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.99 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.887 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.334.157 11.89c0 2.096.547 4.142 1.588 5.945L.057 24l6.326-1.66a11.89 11.89 0 0 0 5.663 1.441h.005c6.554 0 11.89-5.334 11.893-11.89a11.82 11.82 0 0 0-3.48-8.403Z" />
        </svg>
        <span className="hidden text-sm font-bold sm:inline">WhatsApp us</span>
      </a>
    </div>
  );
}
